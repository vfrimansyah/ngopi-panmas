<?= $this->extend('layouts/admin') ?>

<?= $this->section('css') ?>
<style>
    .cursor-pointer {
        cursor: pointer;
    }
    .text-dark-coffee {
        color: #3e2723 !important;
    }
    .text-light-coffee {
        color: #d7ccc8 !important;
    }
    .bg-dark-coffee {
        background-color: #3e2723 !important;
    }
    .bg-gold {
        background-color: #d4af37 !important;
    }
    .text-gold {
        color: #d4af37 !important;
    }
    .fs-7 {
        font-size: 0.8rem;
    }
    .table-warning {
        background-color: #fff3e0 !important;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">
    <div>
        <h4 class="fw-bold mb-0 text-dark-coffee">
            <i class="fa-solid fa-square-poll-vertical me-2 text-gold"></i>Dashboard Pemilu <?= esc($selectedTingkat == 'DPRD_PROV' ? 'DPRD Provinsi Jawa Barat' : ($selectedTingkat == 'DPR_RI' ? 'DPR RI' : 'DPRD Kota Depok')) ?>
        </h4>
        <p class="text-secondary small mb-0">Portal Rekapitulasi Suara & Pemenangan PKS - <?= esc($selectedTingkat == 'DPRD_PROV' ? 'Dapil Jabar 8 (Depok - Bekasi)' : ($selectedTingkat == 'DPR_RI' ? 'Dapil Jabar 6 (Depok - Bekasi)' : 'Kota Depok (Dapil 1 Pancoran Mas)')) ?></p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="<?= base_url('admin/pemilu/heatmap') ?>?tingkat_pemilu=<?= esc($selectedTingkat) ?>" class="btn fw-bold shadow-sm" style="background-color: #3e2723; color: #fff8e1; border-radius: 8px;">
            <i class="fa-solid fa-table-cells me-2 text-warning"></i>Buka Heatmap TPS
        </a>
    </div>
</div>

<!-- FILTER BAR -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; background-color: #efebe9;">
    <div class="card-body p-4">
        <form action="<?= base_url('admin/pemilu/hasil') ?>" method="GET" class="row g-3 align-items-end" id="filterForm">
            <div class="col-md-3">
                <label class="form-label fw-bold text-dark-coffee small"><i class="fa-solid fa-layer-group me-1"></i>Tingkat Pemilu:</label>
                <select name="tingkat_pemilu" class="form-select border-0 shadow-sm text-dark-coffee fw-bold" style="border-radius: 8px; height: 42px;">
                    <?php foreach ($tingkatOptions as $k => $label): ?>
                        <option value="<?= $k ?>" <?= $selectedTingkat == $k ? 'selected' : '' ?>>
                            <?= esc($label) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2">
                <label class="form-label fw-bold text-dark-coffee small"><i class="fa-solid fa-calendar me-1"></i>Tahun:</label>
                <select name="tahun" class="form-select border-0 shadow-sm text-dark-coffee fw-medium" style="border-radius: 8px; height: 42px;">
                    <?php foreach ($years as $yr): ?>
                        <option value="<?= $yr ?>" <?= $selectedYear == $yr ? 'selected' : '' ?>>
                            Tahun <?= esc($yr) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2">
                <label class="form-label fw-bold text-dark-coffee small"><i class="fa-solid fa-map me-1"></i>Kecamatan:</label>
                <select name="district_id" id="districtSelect" class="form-select border-0 shadow-sm text-dark-coffee fw-medium" style="border-radius: 8px; height: 42px;">
                    <?php foreach ($districts as $d): ?>
                        <option value="<?= $d['id'] ?>" <?= $selectedDistrict == $d['id'] ? 'selected' : '' ?>>
                            Kec. <?= esc($d['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label fw-bold text-dark-coffee small"><i class="fa-solid fa-building-flag me-1"></i>Kelurahan:</label>
                <select name="village_id" id="villageSelect" class="form-select border-0 shadow-sm text-dark-coffee fw-medium" style="border-radius: 8px; height: 42px;">
                    <option value="">-- Semua Kelurahan --</option>
                    <?php foreach ($villages as $v): ?>
                        <option value="<?= $v['id'] ?>" <?= $selectedVillage == $v['id'] ? 'selected' : '' ?>>
                            Kel. <?= esc($v['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn w-100 fw-bold border-0 shadow-sm" style="background-color: #3e2723; color: #fff8e1; border-radius: 8px; height: 42px;">
                    <i class="fa-solid fa-filter me-2"></i>Filter
                </button>
                <a href="<?= base_url('admin/pemilu/hasil') ?>" class="btn w-100 fw-bold shadow-sm" style="background-color: #ffffff; color: #3e2723; border: 2px solid #3e2723; border-radius: 8px; height: 42px; line-height: 26px; text-decoration: none; text-align: center;">
                    Reset
                </a>
            </div>
        </form>
    </div>
</div>

<!-- PKS HERO HIGHLIGHT & CORE STATS -->
<div class="row g-4 mb-4">
    <div class="col-lg-6">
        <div class="card border-0 shadow-lg text-white h-100 overflow-hidden position-relative" style="background: linear-gradient(135deg, #f26522, #b73a00); border-radius: 16px;">
            <div class="position-absolute end-0 top-50 translate-middle-y me-4 text-white" style="font-size: 3.75rem; opacity: 0.25; pointer-events: none; line-height: 1; z-index: 1;">
                <i class="fa-solid fa-crown"></i>
            </div>
            <div class="card-body p-4 d-flex flex-column justify-content-between position-relative">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <div class="d-flex align-items-center gap-3">
                        <div class="bg-white p-2 rounded" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
                            <img src="<?= base_url('uploads/partai/' . ($pksStats['lambang_partai'] ?? '')) ?>" alt="PKS" style="max-height: 100%; max-width: 100%; object-fit: contain;" onerror="this.src='https://placehold.co/50?text=PKS';">
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0 text-white">Partai Keadilan Sejahtera</h5>
                            <span class="badge bg-white text-dark fw-bold small">Tahun <?= esc($selectedYear) ?></span>
                        </div>
                    </div>
                    <div class="text-end">
                        <span class="text-uppercase small fw-bold opacity-75 d-block">Peringkat</span>
                        <h3 class="fw-bold mb-0 text-warning"><i class="fa-solid fa-crown text-warning me-1"></i>#<?= $pksRank ?></h3>
                    </div>
                </div>

                <div class="row g-3 py-3 border-top border-bottom border-white border-opacity-25 my-2">
                    <div class="col-6 border-end border-white border-opacity-25">
                        <span class="small opacity-75 d-block">Total Perolehan Suara</span>
                        <h2 class="fw-bold mb-0 text-warning"><?= number_format($pksStats['total_suara'] ?? 0) ?></h2>
                        <span class="small opacity-75">Suara Sah Partai & Caleg</span>
                    </div>
                    <div class="col-6 ps-4">
                        <span class="small opacity-75 d-block">Persentase Suara Sah</span>
                        <h2 class="fw-bold mb-0 text-warning">
                            <?= $totalValidVotes > 0 ? number_format((($pksStats['total_suara'] ?? 0) / $totalValidVotes) * 100, 2) : 0 ?>%
                        </h2>
                        <span class="small opacity-75">Dari total <?= number_format($totalValidVotes) ?> suara</span>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center mt-2 small">
                    <span>Suara Partai: <strong><?= number_format($pksStats['suara_partai'] ?? 0) ?></strong></span>
                    <span>Suara Caleg: <strong><?= number_format($pksStats['suara_caleg'] ?? 0) ?></strong></span>
                </div>
            </div>
        </div>
    </div>

    <!-- GENERAL SUMMARY CARDS -->
    <div class="col-lg-6">
        <div class="row g-3 h-100">
            <div class="col-sm-6">
                <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border-left: 5px solid #3e2723 !important;">
                    <div class="card-body p-4 position-relative overflow-hidden">
                        <div class="position-absolute end-0 bottom-0 opacity-10 text-secondary me-n2 mb-n2" style="font-size: 5rem;">
                            <i class="fa-solid fa-check-to-slot"></i>
                        </div>
                        <h6 class="text-uppercase small fw-bold text-muted">TPS Terproses</h6>
                        <h3 class="fw-bold mb-0 text-dark-coffee"><?= number_format($summary['tps_count'] ?? 0) ?></h3>
                        <p class="small text-muted mb-0 mt-2">Wilayah Pemilihan Terproses</p>
                    </div>
                </div>
            </div>

            <div class="col-sm-6">
                <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border-left: 5px solid #1976d2 !important;">
                    <div class="card-body p-4 position-relative overflow-hidden">
                        <div class="position-absolute end-0 bottom-0 opacity-10 text-primary me-n2 mb-n2" style="font-size: 5rem;">
                            <i class="fa-solid fa-users"></i>
                        </div>
                        <h6 class="text-uppercase small fw-bold text-muted">Total Suara Masuk</h6>
                        <h3 class="fw-bold mb-0 text-primary"><?= number_format($summary['suara_total'] ?? 0) ?></h3>
                        <p class="small text-muted mb-0 mt-2">Partisipasi kehadiran pemilih</p>
                    </div>
                </div>
            </div>

            <div class="col-sm-6">
                <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border-left: 5px solid #2e7d32 !important;">
                    <div class="card-body p-4 position-relative overflow-hidden">
                        <div class="position-absolute end-0 bottom-0 opacity-10 text-success me-n2 mb-n2" style="font-size: 5rem;">
                            <i class="fa-solid fa-circle-check"></i>
                        </div>
                        <h6 class="text-uppercase small fw-bold text-muted">Suara Sah</h6>
                        <h3 class="fw-bold mb-0 text-success"><?= number_format($summary['suara_sah'] ?? 0) ?></h3>
                        <p class="small text-muted mb-0 mt-2">
                            <?= ($summary['suara_total'] ?? 0) > 0 ? number_format(($summary['suara_sah'] / $summary['suara_total']) * 100, 2) : 0 ?>% dari total suara
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-sm-6">
                <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border-left: 5px solid #c62828 !important;">
                    <div class="card-body p-4 position-relative overflow-hidden">
                        <div class="position-absolute end-0 bottom-0 opacity-10 text-danger me-n2 mb-n2" style="font-size: 5rem;">
                            <i class="fa-solid fa-circle-xmark"></i>
                        </div>
                        <h6 class="text-uppercase small fw-bold text-muted">Suara Tidak Sah</h6>
                        <h3 class="fw-bold mb-0 text-danger"><?= number_format($summary['suara_tidak_sah'] ?? 0) ?></h3>
                        <p class="small text-muted mb-0 mt-2">
                            <?= ($summary['suara_total'] ?? 0) > 0 ? number_format(($summary['suara_tidak_sah'] / $summary['suara_total']) * 100, 2) : 0 ?>% dari total suara
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- TOP 10 PARTIES & POSITION HIGHLIGHT -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px;">
    <div class="card-header p-4 bg-transparent border-0 d-flex justify-content-between align-items-center">
        <h5 class="fw-bold mb-0 text-dark-coffee">
            <i class="fa-solid fa-trophy text-gold me-2"></i>10 Besar Perolehan Suara Total Partai
        </h5>
        <span class="badge bg-gold text-dark fs-7 px-3 py-1 fw-bold"><?= esc($selectedTingkat == 'DPRD_PROV' ? 'DPRD Provinsi Jabar (Dapil 8)' : ($selectedTingkat == 'DPR_RI' ? 'DPR RI (Dapil Jabar 6)' : 'DPRD Kota Depok (Dapil 1)')) ?></span>
    </div>
    <div class="card-body p-4 pt-0">
        <div class="row g-4">
            <div class="col-lg-6">
                <h6 class="text-uppercase fw-bold text-muted small mb-3">Grafik Perolehan Suara (Top 10)</h6>
                <?php 
                $limit = 10;
                $count = 0;
                $maxVotes = count($partyResults) > 0 ? $partyResults[0]['total_suara'] : 1;
                foreach ($partyResults as $r): 
                    if ($count++ >= $limit) break;
                    $percent = $totalValidVotes > 0 ? ($r['total_suara'] / $totalValidVotes) * 100 : 0;
                    $barWidth = ($r['total_suara'] / $maxVotes) * 100;
                    $isPKS = ($r['id'] == $pksId);
                ?>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold small text-dark-coffee">
                                <?= $isPKS ? '<i class="fa-solid fa-star text-gold me-1"></i>' : '' ?>
                                <?= $r['no_urut'] ?>. <?= esc($r['nama_partai']) ?>
                            </span>
                            <span class="small fw-bold text-dark-coffee">
                                <?= number_format($r['total_suara']) ?> suara (<?= number_format($percent, 2) ?>%)
                            </span>
                        </div>
                        <div class="progress" style="height: 14px; border-radius: 6px;">
                            <div class="progress-bar" role="progressbar" 
                                 style="width: <?= $barWidth ?>%; background: <?= $isPKS ? 'linear-gradient(90deg, #f26522, #ff9100)' : '#b0bec5' ?>; border-radius: 6px;" 
                                 aria-valuenow="<?= $r['total_suara'] ?>" aria-valuemin="0" aria-valuemax="<?= $maxVotes ?>">
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="col-lg-6">
                <h6 class="text-uppercase fw-bold text-muted small mb-3">Detail Klasemen Partai</h6>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-3" style="width: 50px;">#</th>
                                <th style="width: 80px;">No Urut</th>
                                <th>Partai Politik</th>
                                <th class="text-end" style="width: 120px;">Total Suara</th>
                                <th class="text-end pe-3" style="width: 100px;">Persentase</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $rank = 1;
                            $count = 0;
                            foreach ($partyResults as $r): 
                                if ($count++ >= $limit) break;
                                $percent = $totalValidVotes > 0 ? ($r['total_suara'] / $totalValidVotes) * 100 : 0;
                                $isPKS = ($r['id'] == $pksId);
                            ?>
                                <tr class="<?= $isPKS ? 'table-warning border border-2 border-warning' : '' ?>" style="font-weight: <?= $isPKS ? 'bold' : 'normal' ?>;">
                                    <td class="ps-3 text-muted"><?= $rank++ ?></td>
                                    <td class="text-center"><?= esc($r['no_urut']) ?></td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <?php if (!empty($r['lambang_partai'])): ?>
                                                <img src="<?= base_url('uploads/partai/' . $r['lambang_partai']) ?>" alt="Logo" class="rounded" style="width: 24px; height: 24px; object-fit: contain;">
                                            <?php endif; ?>
                                            <span><?= esc($r['nama_partai']) ?></span>
                                        </div>
                                    </td>
                                    <td class="text-end text-dark-coffee"><?= number_format($r['total_suara']) ?></td>
                                    <td class="text-end pe-3 text-secondary"><?= number_format($percent, 2) ?>%</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 5 BESAR RW TERKUAT PKS DI SETIAP KELURAHAN -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px;">
    <div class="card-header p-4 bg-transparent border-0">
        <h5 class="fw-bold mb-0 text-dark-coffee">
            <i class="fa-solid fa-map-location-dot text-gold me-2"></i>5 Besar RW Terkuat PKS di Setiap Kelurahan
        </h5>
        <p class="text-secondary small mb-0 mt-1">Daftar RW dengan kontribusi suara PKS tertinggi per wilayah Kelurahan</p>
    </div>
    <div class="card-body p-4 pt-0">
        <div class="row g-4">
            <?php foreach ($topRwsPerKelurahan as $kelName => $rws): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card border-0 shadow-sm h-100 bg-light-subtle" style="border-radius: 12px; border-top: 4px solid #f26522 !important;">
                        <div class="card-body p-3">
                            <h6 class="fw-bold text-dark-coffee mb-3 border-bottom pb-2 d-flex justify-content-between align-items-center">
                                <span><i class="fa-solid fa-building me-2 text-gold"></i>Kel. <?= esc($kelName) ?></span>
                                <span class="badge bg-warning text-dark small font-monospace">Top 5 RW</span>
                            </h6>
                            <?php if (empty($rws)): ?>
                                <p class="text-muted small py-4 text-center">Belum ada data suara.</p>
                            <?php else: ?>
                                <?php 
                                $maxRwVotes = count($rws) > 0 ? $rws[0]['total_suara'] : 1;
                                foreach ($rws as $rw): 
                                    $rwPercent = ($rw['total_suara'] / $maxRwVotes) * 100;
                                ?>
                                    <div class="mb-2">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span class="small fw-semibold text-dark-coffee">RW <?= esc($rw['rw']) ?></span>
                                            <span class="small fw-bold text-dark-coffee"><?= number_format($rw['total_suara']) ?> suara</span>
                                        </div>
                                        <div class="progress" style="height: 8px; border-radius: 4px;">
                                            <div class="progress-bar" role="progressbar" 
                                                 style="width: <?= $rwPercent ?>%; background-color: #ff9100; border-radius: 4px;" 
                                                 aria-valuenow="<?= $rw['total_suara'] ?>" aria-valuemin="0" aria-valuemax="<?= $maxRwVotes ?>">
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- INTERACTIVE CALEG AND DETAIL LIST -->
<div class="row g-4">
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px;">
            <div class="card-header p-4 bg-transparent border-0">
                <h5 class="fw-bold mb-0 text-dark-coffee">Daftar Semua Partai</h5>
                <p class="text-muted small mb-0 mt-1">Pilih baris untuk memuat suara caleg secara interaktif.</p>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="partyTable">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 60px;">#</th>
                                <th style="width: 80px;">No Urut</th>
                                <th>Partai Politik</th>
                                <th class="text-end pe-4" style="width: 120px;">Total Suara</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $rank = 1;
                            foreach ($partyResults as $r): 
                                $isPKS = ($r['id'] == $pksId);
                            ?>
                                <tr class="party-row cursor-pointer <?= $isPKS ? 'table-warning' : '' ?>" data-id="<?= $r['id'] ?>" data-name="<?= esc($r['nama_partai']) ?>" style="cursor: pointer;">
                                    <td class="ps-4 text-muted"><?= $rank++ ?></td>
                                    <td class="text-center fw-bold"><?= esc($r['no_urut']) ?></td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <?php if (!empty($r['lambang_partai'])): ?>
                                                <img src="<?= base_url('uploads/partai/' . $r['lambang_partai']) ?>" alt="Logo" class="rounded" style="width: 24px; height: 24px; object-fit: contain;">
                                            <?php endif; ?>
                                            <span><?= esc($r['nama_partai']) ?></span>
                                        </div>
                                    </td>
                                    <td class="text-end pe-4 fw-bold text-dark-coffee"><?= number_format($r['total_suara']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px;">
            <div class="card-header p-4 bg-transparent border-0">
                <h5 class="fw-bold mb-0 text-dark-coffee" id="calegTitle">Perolehan Suara Caleg</h5>
                <p class="text-muted small mb-0 mt-1">Daftar perolehan suara caleg dari partai terpilih.</p>
            </div>
            <div class="card-body p-4 pt-0">
                <div class="alert alert-secondary d-flex align-items-center gap-3 border-0 d-none" role="alert" id="welcomeAlert" style="border-radius: 8px;">
                    <i class="fa-solid fa-arrow-left text-secondary fs-4"></i>
                    <div>Pilih partai pada tabel untuk menampilkan perolehan suara Caleg.</div>
                </div>
                <div id="calegLoader" class="text-center py-5 d-none">
                    <div class="spinner-border text-warning" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="text-muted small mt-2">Memuat suara caleg...</p>
                </div>
                <div id="calegContainer">
                    <ul class="list-group list-group-flush" id="calegList">
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const selectedYear = "<?= $selectedYear ?>";
    const selectedTingkat = "<?= $selectedTingkat ?>";
    const selectedDistrict = "<?= $selectedDistrict ?>";
    const selectedVillage = "<?= $selectedVillage ?>";

    const rows = document.querySelectorAll('.party-row');
    const calegTitle = document.getElementById('calegTitle');
    const calegList = document.getElementById('calegList');
    const calegContainer = document.getElementById('calegContainer');
    const calegLoader = document.getElementById('calegLoader');
    const welcomeAlert = document.getElementById('welcomeAlert');

    const districtSelect = document.getElementById('districtSelect');
    if (districtSelect) {
        districtSelect.addEventListener('change', function() {
            const vSelect = document.getElementById('villageSelect');
            if (vSelect) vSelect.value = '';
            this.form.submit();
        });
    }

    rows.forEach(row => {
        row.addEventListener('click', function() {
            rows.forEach(r => r.classList.remove('table-active'));
            this.classList.add('table-active');

            const partyId = this.getAttribute('data-id');
            const partyName = this.getAttribute('data-name');

            if (welcomeAlert) welcomeAlert.classList.add('d-none');
            if (calegContainer) calegContainer.classList.add('d-none');
            if (calegLoader) calegLoader.classList.remove('d-none');
            if (calegTitle) calegTitle.innerText = "Suara Caleg " + partyName;

            fetch(`<?= base_url('admin/pemilu/hasil/get_candidates') ?>?partai_id=${partyId}&tahun=${selectedYear}&district_id=${selectedDistrict}&village_id=${selectedVillage}&tingkat_pemilu=${selectedTingkat}`)
                .then(response => response.json())
                .then(data => {
                    if (calegLoader) calegLoader.classList.add('d-none');
                    if (calegContainer) calegContainer.classList.remove('d-none');
                    if (calegList) {
                        calegList.innerHTML = '';
                        if (data.length === 0) {
                            calegList.innerHTML = '<li class="list-group-item text-center text-muted py-4">Tidak ada data caleg untuk partai ini.</li>';
                            return;
                        }

                        data.forEach((c) => {
                            const li = document.createElement('li');
                            li.className = 'list-group-item d-flex justify-content-between align-items-center py-3 border-0 border-bottom';
                            li.innerHTML = `
                                <div class="d-flex align-items-center gap-3">
                                    <span class="fw-bold text-muted" style="width: 24px;">${c.no_urut}.</span>
                                    <div>
                                        <span class="fw-semibold text-dark-coffee">${c.nama_caleg}</span>
                                    </div>
                                </div>
                                <span class="badge bg-gold text-dark fs-7 px-3 py-1 fw-bold">${parseInt(c.total_suara).toLocaleString()} suara</span>
                            `;
                            calegList.appendChild(li);
                        });
                    }
                })
                .catch(err => {
                    if (calegLoader) calegLoader.classList.add('d-none');
                    if (welcomeAlert) welcomeAlert.classList.remove('d-none');
                });
        });
    });

    const pksRow = document.querySelector('.party-row.table-warning');
    if (pksRow) {
        pksRow.click();
    } else if (rows.length > 0) {
        rows[0].click();
    }
});
</script>
<?= $this->endSection() ?>
